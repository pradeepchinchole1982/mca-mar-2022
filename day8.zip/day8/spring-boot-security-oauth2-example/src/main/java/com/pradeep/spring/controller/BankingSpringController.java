package com.pradeep.spring.controller;

import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.pradeep.spring.service.AccountService;

@Controller
public class BankingSpringController {
	@Autowired
	private AccountService accountService;
	

	public BankingSpringController() {
		System.out.println("BankingSpringController App created....");
	}

	@RequestMapping("/welcome")
	public String welcome(){
		return "welcome";
	}
	
	/*@RequestMapping("/saccounts")
	public ModelAndView getAllAccounts(){
		return new ModelAndView("accountList","accounts", accountService.getAccountList());
		
	}*/
	
	@RequestMapping("/today")
	public String today(ModelMap map){
		map.addAttribute("today",new Date());
		
		return "today";
	}
	
	@RequestMapping("/time")
	public @ResponseBody String time(){
		
		return "Hello All Current Time is :"+new Date();
	}
	
	
}
