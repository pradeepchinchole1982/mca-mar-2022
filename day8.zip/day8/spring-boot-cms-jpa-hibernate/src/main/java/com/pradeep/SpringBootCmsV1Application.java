package com.pradeep;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCmsV1Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootCmsV1Application.class, args);
	}

}
