package com.pradeep.cms.rest.controllers;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;


import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.ICustomerService;


@RequestMapping("/rest/customers")
@RestController
//@Component("customerMainApp")
public class CustomerRestController {

	
	@Qualifier("customerServiceImpl")
	@Autowired
	//Dependency
	private ICustomerService cs;

	public CustomerRestController() {
		System.out.println("===========CustomerRestController default constructor=========");

	}
	
	
	
	@GetMapping
	public List<Customer> getAllCustomers(){
		return cs.findAllCustomers();
	}
	
	@GetMapping("/{customerId}")
	public Customer getCustomer(@PathVariable("customerId") int cust_id){
		return cs.findCustomer(cust_id);
	}
	
	
	@ResponseStatus(value = HttpStatus.NO_CONTENT)
	@DeleteMapping("/{customerId}")
	public void deleteCustomer(@PathVariable("customerId") int cust_id){
				cs.deleteCustomer(cust_id);
	}
	
	
	@ResponseStatus(value = HttpStatus.OK)
	@PutMapping("/{customerId}")
	public void updateCustomer(@PathVariable("customerId") int cust_id, @RequestBody Customer customer){
	   	cs.updateCustomer(customer);		
	}

	
	@ResponseStatus(value = HttpStatus.CREATED)
	@PostMapping
	public void addCustomer(@RequestBody Customer customer){
	   	cs.saveCustomer(customer);		
	}


	}
