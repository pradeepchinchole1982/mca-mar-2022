package com.pradeep.cms.domain;

import java.util.Date;
import java.util.Random;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name ="pc_customer")
public class Customer {
	
@Id	
private int	customerId;
private String  name;
private String pan;
private String mobile;
private String email;

private String  address;

@Column(name ="dateOfBirth")
private Date  dob;

public Customer() {
customerId=new Random().nextInt(100000);
}

public Customer(String name, String pan, String mobile, String email, String address, Date dob) {
	super();
	customerId=new Random().nextInt(100000);
	this.name = name;
	this.pan = pan;
	this.mobile = mobile;
	this.email = email;
	this.address = address;
	this.dob = dob;
}

public int getCustomerId() {
	return customerId;
}

public void setCustomerId(int customerId) {
	this.customerId = customerId;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getPan() {
	return pan;
}

public void setPan(String pan) {
	this.pan = pan;
}

public String getMobile() {
	return mobile;
}

public void setMobile(String mobile) {
	this.mobile = mobile;
}

public String getEmail() {
	return email;
}

public void setEmail(String email) {
	this.email = email;
}

public String getAddress() {
	return address;
}

public void setAddress(String address) {
	this.address = address;
}

public Date getDob() {
	return dob;
}

public void setDob(Date dob) {
	this.dob = dob;
}

@Override
public String toString() {
	return "Customer [customerId=" + customerId + ", name=" + name + ", pan=" + pan + ", mobile=" + mobile + ", email="
			+ email + ", address=" + address + ", dob=" + dob + "]";
}
	
}
