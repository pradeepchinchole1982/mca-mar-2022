Step 1: Build the Project

         mvn clean package install

Step 2 : Create Dockerfile


Step 3: Build the image

            docker build -t pradeepch82/storeapp:1.1 .

Step 3: Login to Docker hub

           docker login
              username :pradeepch82
              password : 

Step 4: Push the images to docker hub

        docker push pradeepch82/storeapp:1.1

Step 5: Run the container

         docker run --name a-storeapp -p 1111:8080 pradeepch82/storeapp:1.1





 
