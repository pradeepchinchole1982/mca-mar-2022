package com.pradeep.consumer.proxy;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.pradeep.consumer.fallback.ProductServiceFallback;
import com.pradeep.productservice.domain.Product;

@FeignClient(name = "product-service", fallback = ProductServiceFallback.class)
public interface ProductServiceProxy {

	@GetMapping(value = "/products/{id}", produces = { MediaType.APPLICATION_JSON_VALUE })
	Product findProductById(@PathVariable("id") int productId);

	@GetMapping(value = "/products", produces = { MediaType.APPLICATION_JSON_VALUE })
	List<Product> findAllProducts();

	@GetMapping(value = "/", produces = { MediaType.TEXT_PLAIN_VALUE })
	public String getProducts();

	@GetMapping(value = "/get-port", produces = { MediaType.TEXT_PLAIN_VALUE })
	String getPort();

}
