package com.controllers;

import java.util.logging.Logger;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

@RestController
public class SpringController {


	@Autowired
	private RestTemplate restTemplate;

	@Value("${server.port:1111}")
	int port;

	@Value("${info.version:1}")
	String info;

	Logger logger = Logger.getLogger("com.controllers.SpringController");

	public SpringController() {
		System.out.println("========Spring Controller created==========");
	}

	@GetMapping("/") public String index() { 
			return "Customer Service runnig at port   ["+port+"] and version is :"+info;
	}

	@GetMapping("/hi")
	public String hello() {
		return "Hi all,Welcome to Spring Boot application";
	}

	@GetMapping("/welcome1")
	public String welcome() {
		return "Welcome to Spring Boot application";
	}

	@GetMapping("/error")
	public String error() {
		return "We are facing some issue Sorry for inconvinence";
	}

	@GetMapping("/getproductsfromotherservice")
	public String getProductsFromOtherService() {
		logger.info("#####Customer Service calling ProductsService getAllProducts method#############");
		return restTemplate.getForObject("http://PRODUCT-SERVICE/products", String.class);
	}

	@GetMapping("/getproductfromotherservice/{productId}")
	public String getProductsFromOtherService(@PathVariable("productId") int productId) {
		logger.info("#####Customer Service calling ProductsService getProductById method#############");
		return restTemplate.getForObject("http://PRODUCT-SERVICE/products/" + productId, String.class);
	}

}
