package com.pradeep.storeapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StoreappApiGatewayApplicationTests {

	@Test
	void contextLoads() {
	}

}
