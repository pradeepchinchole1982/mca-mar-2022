Step 1: Build the Project

         mvn clean package install

Step 2 : Create Dockerfile


Step 3: Build the image

            docker build -t pradeepch82/storeapp:1.1 .

Step 3: Login to Docker hub

           docker login
              username :pradeepch82
              password : 

Step 4: Push the images to docker hub

        docker push pradeepch82/storeapp:1.1

Step 5: Run the container

         docker run --name a-storeapp -p 1111:8080 pradeepch82/storeapp:1.1

Pass h2 details as env variables
-------------------------------------------------

   docker run --name a-storeapp    -e RDS_URL=jdbc:h2:mem:sivadb  -e RDS_DRIVER_CLASS=org.h2.Driver  -e RDS_USERNAME=sa  -e RDS_PASSWORD=password -e RDS_DIALECT=org.hibernate.dialect.H2Dialect    -p 1111:8080 pradeepch82/storeapp:1.1


Create MySQL container
-----------------------------------
docker run --name a-mysql  -e MYSQL_ROOT_PASSWORD=admin -e MYSQL_DATABASE=mydb -e MYSQL_USER=pradeep -e MYSQL_PASSWORD=pradeep  -d mysql:5.7
 

To know the ip addreess use below command
---------------------------------------------------------------
docker network inpsect bridge

172.17.0.2


Pass MySQL details as env variables
-------------------------------------------------
docker run --name a-storeapp    -e RDS_URL=jdbc:mysql://172.17.0.2:3306/mydb  -e RDS_DRIVER_CLASS=com.mysql.jdbc.Driver  -e RDS_USERNAME=pradeep  -e RDS_PASSWORD=pradeep -e RDS_DIALECT=org.hibernate.dialect.MySQL5Dialect    -p 1111:8080 -d pradeepch82/storeapp:1.1










 
