package com.pradeep.cms.rest;

import java.util.Collection;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.pradeep.cms.domain.Customer;
import com.pradeep.cms.service.CustomerService;

@RequestMapping("/rest/customers")
@RestController
public class CustomerRestController {

	@Qualifier("mapCustomerServiceImpl")
	
	@Autowired
	private CustomerService cs;

	public CustomerRestController() {
		System.out.println("================CustomerRestController created==================");
	}

	@GetMapping
	public Collection<Customer> getCustomers() {
		return cs.findAllCustomers();
	}

	@GetMapping("/{customerId}")
	public Customer getCustomerById(@PathVariable("customerId") int customerId) {
		return cs.findCustomerById(customerId);
	}

	@DeleteMapping("/{customerId}")
	public Collection<Customer> deleteCustomerById(@PathVariable("customerId") int customerId) {
		cs.deleteCustomer(customerId);
		return cs.findAllCustomers();
	}

	@PutMapping("/{customerId}")
	public Collection<Customer> updateCustomerById(@PathVariable("customerId") int customerId,
			@RequestBody Customer customer) {
		System.out.println("In updateCustomer :"+customer);
		cs.updateCustomer(customer);
		return cs.findAllCustomers();
	}

	@PostMapping
	public Collection<Customer> addCustomer(@RequestBody Customer customer) {
		System.out.println("In addCustomer :"+customer);
		cs.saveCustomer(customer);
		return cs.findAllCustomers();
	}

}
